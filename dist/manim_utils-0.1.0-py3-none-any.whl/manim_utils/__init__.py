from .data_scene import DataScene, Provider
from .new_image_mobject import ImageMobject
from .new_svg_mobject import SVGMobject
from .scatter_plot import ScatterPlot
from .new_table import Table
from .matplotlib_to_manim import scatter_matplotlib_to_manim
